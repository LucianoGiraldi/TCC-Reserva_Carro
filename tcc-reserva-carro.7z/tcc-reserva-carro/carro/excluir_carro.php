<?php
include_once("../sessao/includes.php");

if (isset($_POST["excluir_carro"])) {
    $conn = $_SESSION["conexao"];
    $idcarro = $_POST["idcarro"];

    // Excluir registros de agendamento associados ao carro
    $sqlAgendamento = "DELETE FROM agendamento WHERE carro_idcarro = $idcarro";

    if (mysqli_query($conn, $sqlAgendamento)) {
        // Excluir registro do carro
        $sqlCarro = "DELETE FROM carro WHERE idcarro = $idcarro";

        if (mysqli_query($conn, $sqlCarro)) {
            ?>
            <script>
                window.location.href = "lista_carro.php";
                alert("Carro excluído com sucesso!");
            </script>
            <?php
        } else {
            ?>
            <script>
                window.location.href = "lista_carro.php";
                alert("Erro ao excluir o carro.");
            </script>
            <?php
        }
    } else {
        ?>
        <script>
            window.location.href = "lista_carro.php";
            alert("Erro ao excluir os agendamentos do carro.");
        </script>
        <?php
    }
}
?>
